//
//  EmployeeVC.swift
//  Demo
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class EmployeeVC: UIViewController {

    
    @IBOutlet weak var tfEmpId: UITextField!
    
    @IBOutlet weak var tfEmpName: UITextField!
    
    
    @IBOutlet weak var tfEmpBirthdate: UITextField!
    
    
    @IBOutlet weak var tfEmpSalary: UITextField!
    
    
    
    @IBAction func btnSave(_ sender: UIButton) {
       
        let emp = Employee()
        emp.empId = Int(tfEmpId.text!);
        emp.empName = tfEmpName.text!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-mm-yyyy"
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        emp.birthDate = dateFormatter.date(from: tfEmpBirthdate.text!)
        
        emp.salary = Double(tfEmpSalary.text!)
        let flag = Employee.addEmployee(emp: emp)
        if flag == true {
            print("employee record saved")
        }else
        {
            print("possible duplication error!!")
        }
        
        
       
        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
