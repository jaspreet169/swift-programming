//
//  Employee.swift
//  Demo
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation



class Employee{
    
    var empId:Int!
    var empName:String!
    var birthDate: Date!
    var salary:Double!
    static var employeeList = [Int:Employee]()
    
    init (){
        self.empId = -1
        self.empName = ""
        self.birthDate = Date()
        self.salary = 0.0
    }
    
    
    init(_empId:Int,_empName:String,_birthdate:Date,_salary:Double){
        self.empId = _empId
        self.empName = _empName
        self.birthDate = _birthdate
        self.salary = _salary
    }
    static func addEmployee(emp:Employee) -> Bool {
        if self.employeeList[emp.empId] == nil{
            self.employeeList[emp.empId] = emp
            return true
        }
        return false
    }
}
